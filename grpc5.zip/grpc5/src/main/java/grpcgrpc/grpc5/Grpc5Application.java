package grpcgrpc.grpc5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Grpc5Application {

	public static void main(String[] args) {
		SpringApplication.run(Grpc5Application.class, args);
	}

}
